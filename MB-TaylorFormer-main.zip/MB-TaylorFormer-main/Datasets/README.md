For training and testing, your directory structure should look like this
  
 `Datasets` <br/>
 `├──train`  <br/>
     `└──Rain13K`   <br/>
          `├──input`   <br/>
          `└──target`   <br/>
 `└──test`  <br/>
     `├──Test100`   <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `├──Rain100H`  <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `├──Rain100L`  <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `├──Test1200`  <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `└──Test2800`<br/>
          `├──input`   <br/>
          `└──target` 
