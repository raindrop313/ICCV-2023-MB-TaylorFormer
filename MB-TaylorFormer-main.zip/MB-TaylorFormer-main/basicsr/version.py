# GENERATED VERSION FILE
# TIME: Sat Oct  8 23:40:49 2022
__version__ = '1.2.0+10018c6'
short_version = '1.2.0'
version_info = (1, 2, 0)
